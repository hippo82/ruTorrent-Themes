# club-QuickBox
club-QuickBox is a fresh and modernized skin for rTorrent GUI, ruTorrent. This theme has been featured on projects such as Swizards and has been made exclusively for QuickBox.IO. Welcome to club-QuickBox!

## Install

You will need to navigate to your plugins/themes directory, typically located at ```../../rutorrent/plugins/theme/themes```

Next, simply clone the club-QuickBox skin to your themes
```
git clone https://github.com/QuickBox/club-QuickBox.git club-QuickBox
chown -R www-data: club-QuickBox
```
